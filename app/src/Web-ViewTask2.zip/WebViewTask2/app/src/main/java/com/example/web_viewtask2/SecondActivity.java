package com.example.web_viewtask2;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.web_viewtask2.databinding.ActivitySecondBinding;
import com.example.web_viewtask2.models.FlagQuiz;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SecondActivity extends AppCompatActivity implements View.OnClickListener {

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private ActivitySecondBinding binding;
    private Gson gson;
    private int index = 0;
    private List<FlagQuiz> AsiaList;
    boolean f;
    boolean g;
    private List<FlagQuiz> EuropeList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySecondBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        gson = new Gson();
        AsiaList = new ArrayList<>();
        EuropeList = new ArrayList<>();
        /*sharedPreferences = getSharedPreferences("FlagQuiz", MODE_PRIVATE);
        editor = sharedPreferences.edit();*/
        Intent intent = getIntent();
        String code = intent.getStringExtra("code");
        setResult(1, intent);

        if (Integer.parseInt(code) == 1) {
            binding.coins.setText("10");
            binding.theme.setText("Asian countries");
            Intent intent1 = getIntent();
            String asia = intent1.getStringExtra("Asia");

            Type type = new TypeToken<List<FlagQuiz>>() {
            }.getType();
            AsiaList = gson.fromJson(asia, type);
            setQuestions();


        } else if (Integer.parseInt(code) == 2) {

        } else if (Integer.parseInt(code) == 3) {
        } else if (Integer.parseInt(code) == 4) {
        } else if (Integer.parseInt(code) == 5) {

        }

    }

    private void setQuestions() {
        f = false;
        g = false;
        FlagQuiz flagQuiz = AsiaList.get(index);
        Picasso.get().load(flagQuiz.getUrl()).into(binding.image);

        String capital = flagQuiz.getCapital();
        List<String> randomList = getRandomList(capital);

        for (int i = 0; i < randomList.size() / 2; i++) {
            Button button = new Button(this);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT, 1.0f);
            button.setText(randomList.get(i));
            button.setBackgroundColor(Color.parseColor("#31C905"));
            button.setLayoutParams(layoutParams);
            button.setOnClickListener(this);
            binding.layout2.addView(button);
        }
        for (int i = randomList.size() / 2; i < randomList.size(); i++) {
            Button button = new Button(this);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT, 1.0f);
            button.setText(randomList.get(i));
            button.setBackgroundColor(Color.parseColor("#31C905"));
            button.setLayoutParams(layoutParams);
            button.setOnClickListener(this);
            binding.layout3.addView(button);
        }
        binding.capital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (binding.layout1.getChildCount() != 0) {
                    Toast.makeText(SecondActivity.this, "Siz bundan faqat birinchi harf uchun foydalana olasiz!", Toast.LENGTH_SHORT).show();
                } else {
                    if (f == false) {
                        f = true;
                        if (Integer.parseInt(binding.coins.getText().toString()) >= 5) {
                            FlagQuiz flagQuiz1 = AsiaList.get(index);
                            String s = flagQuiz1.getCapital().substring(0, 1).toUpperCase();
                            Button button = new Button(SecondActivity.this);
                            button.setText(s);
                            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT, 1.0f);
                            button.setLayoutParams(layoutParams);
                            binding.layout1.addView(button);
                            button.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    binding.layout1.removeAllViews();
                                    f = false;
                                }
                            });
                            binding.coins.setText(String.valueOf(Integer.parseInt(binding.coins.getText().toString()) - 5));
                        } else {
                            Toast.makeText(SecondActivity.this, "Sizda yordam olish uchun yetarli ball mavjud emas", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                /*boolean bool = false;
                int index1 = -1;
                FlagQuiz flagQuiz1 = AsiaList.get(index);
                String substring = flagQuiz1.getCapital().substring(0, 1).toUpperCase();
                if (binding.layout1.getChildAt(0).isShown()) {
                    for (int i = 0; i < binding.layout2.getChildCount(); i++) {
                        if (binding.layout2.getChildAt(i).getTooltipText() == substring) {
                            bool = true;
                            index1 = i;
                            break;
                        } else {
                            bool = false;
                        }
                    }
                    if (bool) {
                        binding.layout1.addView(binding.layout2.getChildAt(index1));
                        binding.layout2.getChildAt(index1).setVisibility(View.INVISIBLE);
                    } else {
                        for (int i = 0; i < binding.layout3.getChildCount(); i++) {
                            if (binding.layout3.getChildAt(i).getTooltipText() == substring) {
                                binding.layout1.addView(binding.layout3.getChildAt(i));
                                binding.layout3.getChildAt(i).setVisibility(View.INVISIBLE);
                            }
                        }
                    }

                }*/


            }
        });
        binding.country.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Integer.parseInt(binding.coins.getText().toString()) >= 5) {
                    FlagQuiz flagQuiz1 = AsiaList.get(index);
                    Toast.makeText(SecondActivity.this, flagQuiz1.getCountry(), Toast.LENGTH_SHORT).show();
                    binding.coins.setText(String.valueOf(Integer.parseInt(binding.coins.getText().toString()) - 5));
                } else {
                    Toast.makeText(SecondActivity.this, "Sizda yordam olish uchun yetarli ball mavjud emas", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    private List<String> getRandomList(String capital) {
        int a = capital.length();
        String b = "ABDEFGHIJKLMNOPQRSTUVXYZOGC`";
        int c = 18 - a;
        String str = b.substring(0, c);
        String d = capital.toUpperCase().concat(str);
        List<String> charList = new ArrayList<>();
        for (int i = 0; i < d.length(); i++) {
            charList.add(d.substring(i, i + 1));
        }
        Collections.shuffle(charList);

        return charList;
    }

    @Override
    public void onClick(View v) {
        Button v1 = (Button) v;
        if (binding.layout1.getChildCount() == AsiaList.get(index).getCapital().length()) {
            v1.setClickable(false);
        } else {
            Button button = (Button) v;

            String text = button.getText().toString();
            button.setVisibility(View.INVISIBLE);

            Button topButton = new Button(this);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT, 1.0f);
            topButton.setBackgroundColor(Color.parseColor("#31C905"));
            topButton.setLayoutParams(layoutParams);
            topButton.setText(text);

            binding.layout1.addView(topButton);
            topButton.setOnClickListener(v2 -> {
                binding.layout1.removeView(topButton);
                button.setVisibility(View.VISIBLE);
                button.setClickable(true);
            });
            int childCount = binding.layout1.getChildCount();
            FlagQuiz flagQuiz = AsiaList.get(index);
            int length = flagQuiz.getCapital().length();
            if (childCount == length) {
                StringBuilder stringBuilder = new StringBuilder();
                for (int i = 0; i < childCount; i++) {
                    View childAt = binding.layout1.getChildAt(i);
                    Button childAt1 = (Button) childAt;
                    stringBuilder.append(childAt1.getText().toString());
                }
                if (stringBuilder.toString().equals(flagQuiz.getCapital().toUpperCase())) {
                    Toast.makeText(this, "Qoyil! Siz to`g`ri topdingiz!", Toast.LENGTH_SHORT).show();
                    binding.coins.setText(String.valueOf(Integer.parseInt(binding.coins.getText().toString()) + 10));
                    if (index == AsiaList.size() - 1) {
                        Intent intent = new Intent(this, DialogActivity.class);
                        startActivity(intent);

                    } else {
                        index++;
                        binding.layout1.removeAllViews();
                        binding.layout2.removeAllViews();
                        binding.layout3.removeAllViews();
                        setQuestions();
                    }
                } else {
                    Toast.makeText(this, "Noto`g`ri", Toast.LENGTH_SHORT).show();
                }

            }


        }
    }
}