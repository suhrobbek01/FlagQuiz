package com.example.web_viewtask2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.example.web_viewtask2.databinding.ActivityRulesBinding;

public class Rules extends AppCompatActivity {

    private ActivityRulesBinding binding;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRulesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sharedPreferences = getSharedPreferences("FlagQuiz", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        String rules = sharedPreferences.getString("rules", "");
        binding.tv2.setText(rules);
        Intent intent = new Intent();
        setResult(1, intent);
    }

    private static final String TAG = "Rules";

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}