package com.example.web_viewtask2;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import com.example.web_viewtask2.databinding.ActivityMainBinding;
import com.example.web_viewtask2.models.FlagQuiz;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private List<FlagQuiz> flagAsia;
    private List<FlagQuiz> flagEurope;
    private List<FlagQuiz> flagAmerica;
    private List<FlagQuiz> flagAfrica;
    private List<FlagQuiz> flagQuizList;
    private String rules;
    private Gson gson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        loadFlags();

        gson = new Gson();
        sharedPreferences = getSharedPreferences("FlagQuiz", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        rules = "   Assalomu alaykum, aziz foydalanuvchi! Ushbu dasturimiz sizga ma`qul keladi degan umiddamiz." + "\n" + "   Ushbu dasturdan foydalanishdan oldin o`yin qoidalari bilan tanishib chiqishni maslahat beramiz." + "\n" + "   1.Siz asosiy oynada o`zingiz xohlagan bitta qit`a nomini tanlashingiz kerak bo`ladi." + "\n" + "   2.Sizga tanlagan qit`angizga mos davlat bayrog`laridan biri ko`rsatiladi. Va siz shu davlat poytaxti nomini topib, pastda berilgan tugmalarni bosish orqali poytaxt nomini kiritishingiz kerak bo`ladi." + "\n" + "   3.Agar siz poytaxt nomini to`g`ri topsangiz sizga 10 tanga miqdorida ball beriladi. " + "\n" + "   4.Bunda sizga ba`zi yordamlar mavjud. Ya`ni siz bayroq rasmi pastidagi chapda turgan so`roq belgisini bossangiz, sizga poytaxt nomi yoziladigan joyda poytaxt nomining birinchi harfi ko`rsatib beriladi. Shuningdek, agarda siz bayroq qaysi davlatga tegishli ekanligini bilmoqchi bo`lsangiz, so`roq belgisining o`ng tomonidagi lupa ustiga bosganingizda sizga TOAST da bayroq tegishli bo`lgan davlat nomi ko`rsatiladi. Shunga mos ravishda har ikkala tugma bir marotaba bosilganda ballingizdan 5 tanga miqdorida ball olib qolinadi" + "\n" + "   5.Siz barcha qit`alarga tegishli poytaxt nomlarini to`gri topib jami 25 ball to`plashingiz kerak bo`ladi." + "\n" + "   6.Sizda internet aloqasi mavjud bo`lishi shart, chunki rasmlar internet saytlaridan olinadi." + "\n" + "   7.Sizga omad yor bo`lsin!!!";

        binding.rules1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putString("rules", rules).commit();
                Intent intent = new Intent(MainActivity.this, Rules.class);
                launcher.launch(intent);

            }

            ActivityResultLauncher<Intent> launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    Intent data = result.getData();
                }
            });
        });
        binding.asia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("code", "1");
                String flagAsiaToJsonString = gson.toJson(flagAsia);
                intent.putExtra("Asia", flagAsiaToJsonString);
                launcher.launch(intent);
            }

            ActivityResultLauncher<Intent> launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    Intent data = result.getData();
                }
            });
        });
        binding.europe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("code", "2");
                String flagEuropeToJsonString = gson.toJson(flagEurope);
                intent.putExtra("Europe", flagEuropeToJsonString);
                resultLauncher.launch(intent);

            }

            ActivityResultLauncher<Intent> resultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    Intent data = result.getData();
                }
            });
        });

    }

    private void loadFlags() {
        flagAsia = new ArrayList<>();
        flagAsia.add(new FlagQuiz("Anqara", "https://images.unsplash.com/photo-1574367808145-da4fc05cd3eb?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MjQyfHx1emJla2lzdGFuJTIwc3ltYm9sfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60", "Turkiya"));
        flagAsia.add(new FlagQuiz("Nyu Deli", "https://images.unsplash.com/photo-1600317055848-1a78a8bf2fd0?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mjk2fHx1emJla2lzdGFuJTIwc3ltYm9sfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60", "Hindiston"));
        flagAsia.add(new FlagQuiz("Tehron", "https://images.unsplash.com/photo-1612972266008-479c7c2c952a?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80", "Eron"));
        flagAsia.add(new FlagQuiz("Seul", "https://images.unsplash.com/photo-1619179834700-7a886aac80cc?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Nnx8c291dGglMjBrb3JlYSUyMGZsYWd8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60", "Janubiy Koreya"));
        flagAsia.add(new FlagQuiz("Toshkent", "https://storage.kun.uz/source/thumbnails/_medium/7/Z5HQseGjX5aeUngKV0X0s0YjIQF2vrMN_medium.jpg", "O`zbekiston"));


        flagEurope = new ArrayList<>();
        flagEurope.add(new FlagQuiz("London", "https://images.unsplash.com/photo-1598481732567-901732cd829f?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=889&q=80", "Buyuk Britaniya"));
        flagEurope.add(new FlagQuiz("Kopengagen", "https://images.unsplash.com/photo-1579275382872-7fe9b8dec1c6?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=334&q=80", "Daniya"));
        flagEurope.add(new FlagQuiz("Afina", "https://images.unsplash.com/photo-1504824298596-33e362afe457?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=745&q=80", "Gretsiya"));
        flagEurope.add(new FlagQuiz("Parij", "https://images.unsplash.com/photo-1548535520-2ea47f354d7f?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=334&q=80", "Fransiya"));
        flagEurope.add(new FlagQuiz("Lissabon", "https://images.unsplash.com/photo-1605132001479-40ee4f13de0a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8NzJ8fGJhYSUyMCUyMGZsYWd8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60", "Portugaliya"));

        flagAmerica = new ArrayList<>();
        flagAmerica.add(new FlagQuiz("Vashington", "https://images.unsplash.com/photo-1541673153586-ef520dae437a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MjQxfHx1emJla2lzdGFuJTIwc3ltYm9sfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60", "AQSH"));

    }
}