package com.example.web_viewtask2.models;

public class FlagQuiz {
    private String capital;
    private String url;
    private String country;

    public FlagQuiz(String capital, String url, String country) {
        this.capital = capital;
        this.url = url;
        this.country = country;
    }

    public String getCapital() {
        return capital;
    }

    public void setCapital(String capital) {
        this.capital = capital;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
}
